<?php

/**
 * Shortcode: Banner.
 */
require_once  plugin_dir_path( __FILE__ ) . 'banner.php';


/**
 * Shortcode: 3 CTA.
 */
require_once  plugin_dir_path( __FILE__ ) . '3cta.php';


/**
 * Shortcode: Introduction.
 */
require_once  plugin_dir_path( __FILE__ ) . 'introduction.php';


/**
 * Shortcode: Practice Areas.
 */
require_once  plugin_dir_path( __FILE__ ) . 'practice-areas.php';


/**
 * Shortcode: Blog Area.
 */
require_once  plugin_dir_path( __FILE__ ) . 'blog.php';


/**
 * Shortcode: Testimonials.
 */
require_once  plugin_dir_path( __FILE__ ) . 'testimonials.php';


/**
 * Shortcode: Logo Slider.
 */
require_once  plugin_dir_path( __FILE__ ) . 'logo-slider.php';

